### Go data capturer

## Сборка

Соберите проект:

```bash
go build
```

Запустите программу:

```bash
./go-capturer
```

### Пример использования

```bash
./go-capturer -p 9925  -h localhost:8080 -user test@gmail.com -password test
```
